package com.healthycraftybites.menumanagementservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthycraftybites.menumanagementservice.dto.ApiResponse;
import com.healthycraftybites.menumanagementservice.dto.ProductDTO;
import com.healthycraftybites.menumanagementservice.service.MenuService;

@RestController
@RequestMapping("/menumanagementservice/menuservice")
public class MenuServiceController {
	
	@Autowired
	MenuService objMenuService;
	
	@PostMapping("/addnewproduct")
	public ResponseEntity<ApiResponse<ProductDTO>> addNewProduct(@RequestBody ProductDTO objNewProductDTO) {
		ProductDTO savedProduct = objMenuService.addNewProduct(objNewProductDTO);
		
		ApiResponse<ProductDTO> response = ApiResponse.success("Product added successfully", savedProduct);
		
		return new ResponseEntity<>(response,HttpStatus.CREATED);
	} 
}
