package com.healthycraftybites.menumanagementservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.healthycraftybites.menumanagementservice.dto.ApiResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(DuplicateItemException.class)
	public ResponseEntity<ApiResponse<Object>> handleDuplicateItem(DuplicateItemException ex){
		ApiResponse<Object> response = ApiResponse.failure(ex.getMessage());
		return new ResponseEntity<>(response,HttpStatus.CONFLICT);
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ApiResponse<Object>> handleGenericException(Exception ex){
		ApiResponse<Object> response = ApiResponse.failure("Oops! Something went wrong. Please Try Again.");
		return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
