package com.healthycraftybites.menumanagementservice.service;

import com.healthycraftybites.menumanagementservice.dto.ProductDTO;

public interface MenuService {
	public ProductDTO addNewProduct(ProductDTO objNewProductDTO);
}
