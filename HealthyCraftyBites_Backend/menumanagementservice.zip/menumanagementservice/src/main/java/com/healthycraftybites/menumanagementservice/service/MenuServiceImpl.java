package com.healthycraftybites.menumanagementservice.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthycraftybites.menumanagementservice.dto.ProductDTO;
import com.healthycraftybites.menumanagementservice.entity.Product;
import com.healthycraftybites.menumanagementservice.exception.DuplicateItemException;
import com.healthycraftybites.menumanagementservice.repository.MenuServiceRepository;

@Service
public class MenuServiceImpl implements MenuService {

	@Autowired
	MenuServiceRepository objMenuServiceRepository;
	
	@Override
	public ProductDTO addNewProduct(ProductDTO objNewProductDTO) {
		
		boolean productExists = objMenuServiceRepository.existsByName(objNewProductDTO.getName());
		if(productExists) {
			throw new DuplicateItemException(objNewProductDTO.getName()+" already added in Database!");
		}
		
		
		Product objProductToStore = new Product();
		BeanUtils.copyProperties(objNewProductDTO, objProductToStore);
		
		Product objsavedProduct = objMenuServiceRepository.save(objProductToStore);
		
		ProductDTO responseProductDTO = new ProductDTO();
		BeanUtils.copyProperties(objsavedProduct, responseProductDTO);
		
		return responseProductDTO;
	}

}
